import React from "react";

const SomePage = () => {
  return (
    <div className="w-full h-full min-h-screen bg-red-500  flex align-middle justify-center">
      <div className="flex self-center">
        {" "}
        <span className="flex self-center"> hello</span>
        <h1>title</h1>
      </div>
    </div>
  );
};

export default SomePage;
