import React from "react";

const stylist = () => {
  return <div>hello</div>;
};

export default stylist;
